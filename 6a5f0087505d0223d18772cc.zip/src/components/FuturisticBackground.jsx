import React from 'react';

export default function FuturisticBackground() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 0 }}>
      <div id="futuristic-bg-inner" className="absolute inset-0 will-change-transform">
        {/* Moving grid */}
        <div className="absolute inset-0 bg-grid-futuristic" />
        {/* Floating gradient orbs */}
        <div
          className="absolute -top-32 -left-20 w-[500px] h-[500px] rounded-full blur-[120px]"
          style={{ background: 'radial-gradient(circle, rgba(16, 185, 129, 0.12), transparent 70%)', animation: 'float-orb 18s ease-in-out infinite' }}
        />
        <div
          className="absolute -bottom-40 -right-32 w-[600px] h-[600px] rounded-full blur-[140px]"
          style={{ background: 'radial-gradient(circle, rgba(59, 130, 246, 0.10), transparent 70%)', animation: 'float-orb 22s ease-in-out infinite reverse' }}
        />
        <div
          className="absolute top-1/3 left-1/2 w-[400px] h-[400px] rounded-full blur-[110px]"
          style={{ background: 'radial-gradient(circle, rgba(139, 92, 246, 0.08), transparent 70%)', animation: 'float-orb 25s ease-in-out infinite', animationDelay: '5s' }}
        />
        {/* Vignette for depth */}
        <div
          className="absolute inset-0"
          style={{ background: 'radial-gradient(ellipse at center, transparent 30%, rgba(10, 14, 26, 0.5) 100%)' }}
        />
      </div>
    </div>
  );
}