import React, { useMemo } from 'react';
import { X, Trash2, TrendingUp } from 'lucide-react';
import { computeFullModel, applyScenario, fmtCurrency, fmtPercent, fmtPrice, fmtMultiple } from '@/lib/dcfEngine';

export default function CaseComparison({ currentInputs, currentModel, savedCases, onClose, onDeleteCase }) {
  const cases = useMemo(() => {
    const list = [
      { id: 'current', label: 'Current Case', inputs: currentInputs, model: currentModel, isCurrent: true },
    ];
    savedCases.slice(0, 2).forEach(c => {
      const effInputs = applyScenario(c.inputs, c.scenario_key || 'base');
      list.push({
        id: c.id,
        label: c.label || 'Saved Case',
        inputs: effInputs,
        model: computeFullModel(effInputs),
        isCurrent: false,
      });
    });
    return list;
  }, [currentInputs, currentModel, savedCases]);

  const inputRows = [
    { label: 'Historical Revenue', get: i => i.historicalRevenue != null ? fmtCurrency(i.historicalRevenue) : '—' },
    { label: 'Gross Margin', get: i => i.grossMargin != null ? fmtPercent(i.grossMargin) : '—' },
    { label: 'WACC', get: i => i.wacc != null ? fmtPercent(i.wacc) : '—' },
    { label: 'Tax Rate', get: i => i.taxRate != null ? fmtPercent(i.taxRate) : '—' },
    { label: 'Terminal Growth', get: i => i.terminalMethod === 'perpetuity' && i.perpetuityGrowth != null ? fmtPercent(i.perpetuityGrowth) : '—' },
    { label: 'Exit Multiple', get: i => i.terminalMethod === 'multiple' && i.exitMultiple != null ? fmtMultiple(i.exitMultiple) : '—' },
    { label: 'Rev. Growth (Y1)', get: i => i.revenueGrowth?.[0] != null ? fmtPercent(i.revenueGrowth[0]) : '—' },
    { label: 'Rev. Growth (Y5)', get: i => i.revenueGrowth?.[4] != null ? fmtPercent(i.revenueGrowth[4]) : '—' },
  ];

  const metricRows = [
    { label: 'Enterprise Value', get: m => m ? fmtCurrency(m.valuation.enterpriseValue) : '—', highlight: true },
    { label: 'Equity Value', get: m => m ? fmtCurrency(m.valuation.equityValue) : '—', highlight: true },
    { label: 'Implied Share Price', get: m => m ? fmtPrice(m.valuation.impliedSharePrice) : '—' },
    { label: 'Upside / Downside', get: m => m ? fmtPercent(m.valuation.upsideDownside) : '—' },
    { label: 'Terminal Value', get: m => m ? fmtCurrency(m.valuation.terminalValue) : '—' },
    { label: 'Sum PV(UFCF)', get: m => m ? fmtCurrency(m.valuation.sumPvUFCF) : '—' },
  ];

  const ufcfRows = [1, 2, 3, 4, 5].map(year => ({
    label: `UFCF Year ${year}`,
    get: m => m && m.forecast[year - 1] ? fmtCurrency(m.forecast[year - 1].ufcf) : '—',
  }));

  const Section = ({ title }) => (
    <tr><td colSpan={cases.length + 1} className="pt-4 pb-1 px-3 text-[10px] font-semibold text-slate-600 uppercase tracking-wider">{title}</td></tr>
  );

  return (
    <div className="fixed inset-0 z-40 bg-[#0a0e1a] overflow-y-auto">
      <div className="sticky top-0 z-10 bg-[#0a0e1a]/95 backdrop-blur border-b border-slate-800/50 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <TrendingUp className="w-5 h-5 text-emerald-500" />
          <div>
            <h2 className="text-sm font-bold text-slate-100">Case Comparison</h2>
            <p className="text-[11px] text-slate-500">Side-by-side analysis of {cases.length} case{cases.length !== 1 ? 's' : ''}</p>
          </div>
        </div>
        <button onClick={onClose} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800/60 hover:bg-slate-700/60 rounded-lg transition-colors border border-slate-700/50">
          <X className="w-3.5 h-3.5" /> Close
        </button>
      </div>

      <div className="p-6 max-w-6xl mx-auto">
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="border-b border-slate-700/50">
                <th className="text-left px-3 py-3 text-[11px] font-semibold text-slate-500 uppercase tracking-wider whitespace-nowrap">Metric</th>
                {cases.map(c => (
                  <th key={c.id} className="text-center px-3 py-3 whitespace-nowrap">
                    <div className="flex items-center justify-center gap-2">
                      <span className={`text-xs font-semibold ${c.isCurrent ? 'text-emerald-400' : 'text-slate-200'}`}>{c.label}</span>
                      {!c.isCurrent && (
                        <button onClick={() => onDeleteCase(c.id)} className="text-slate-600 hover:text-red-400 transition-colors" title="Delete case">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <Section title="Key Inputs" />
              {inputRows.map((row, i) => (
                <tr key={`input-${i}`} className="border-b border-slate-800/30 hover:bg-slate-800/20">
                  <td className="text-left px-3 py-2 text-xs text-slate-400 whitespace-nowrap">{row.label}</td>
                  {cases.map(c => (
                    <td key={c.id} className="text-center px-3 py-2 text-sm text-slate-200 font-mono whitespace-nowrap">{row.get(c.inputs)}</td>
                  ))}
                </tr>
              ))}

              <Section title="Valuation Outputs" />
              {metricRows.map((row, i) => (
                <tr key={`metric-${i}`} className="border-b border-slate-800/30 hover:bg-slate-800/20">
                  <td className="text-left px-3 py-2 text-xs text-slate-400 whitespace-nowrap">{row.label}</td>
                  {cases.map(c => (
                    <td key={c.id} className={`text-center px-3 py-2 text-sm font-mono whitespace-nowrap ${row.highlight ? 'text-emerald-400 font-semibold' : 'text-slate-200'}`}>{row.get(c.model)}</td>
                  ))}
                </tr>
              ))}

              <Section title="UFCF Forecast" />
              {ufcfRows.map((row, i) => (
                <tr key={`ufcf-${i}`} className="border-b border-slate-800/30 hover:bg-slate-800/20">
                  <td className="text-left px-3 py-2 text-xs text-slate-400 whitespace-nowrap">{row.label}</td>
                  {cases.map(c => (
                    <td key={c.id} className="text-center px-3 py-2 text-sm text-slate-300 font-mono whitespace-nowrap">{row.get(c.model)}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {cases.length < 2 && (
          <p className="text-xs text-slate-600 mt-6 text-center">Save more cases from the dashboard to compare up to 3 scenarios side by side.</p>
        )}
      </div>
    </div>
  );
}