import React from 'react';
import { Building2, Wallet, TrendingUp as TrendingUpIcon, TrendingDown, Info } from 'lucide-react';
import { fmtCurrency, fmtPrice, fmtPercent } from '@/lib/dcfEngine';

function Card({ icon: Icon, label, value, subText, subColor, onAudit, accent }) {
  return (
    <div className="relative bg-[#131825] border border-slate-800/50 rounded-xl p-4 lg:p-5 overflow-hidden group hover:border-slate-700/70 transition-all">
      <div className={`absolute top-0 left-0 w-full h-0.5 ${accent}`} />
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-slate-500" />
          <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">{label}</span>
        </div>
        <button onClick={onAudit} className="opacity-0 group-hover:opacity-100 transition-opacity text-slate-500 hover:text-emerald-400" title="View audit formula">
          <Info className="w-3.5 h-3.5" />
        </button>
      </div>
      <div className="text-xl lg:text-2xl font-bold text-slate-100 font-mono tracking-tight">{value}</div>
      {subText && <div className={`text-xs mt-1 ${subColor}`}>{subText}</div>}
    </div>
  );
}

export default function MetricCards({ model, inputs, onAudit }) {
  const { valuation } = model;
  const isUpside = valuation.upsideDownside >= 0;

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
      <Card
        icon={Building2}
        label="Implied EV"
        value={fmtCurrency(valuation.enterpriseValue)}
        subText={`PV(UFCF): ${fmtCurrency(valuation.sumPvUFCF)}`}
        subColor="text-slate-500"
        onAudit={() => onAudit('ev')}
        accent="bg-blue-500/60"
      />
      <Card
        icon={Wallet}
        label="Equity Value"
        value={fmtCurrency(valuation.equityValue)}
        subText="EV − Debt + Cash − NCI"
        subColor="text-slate-500"
        onAudit={() => onAudit('equity')}
        accent="bg-purple-500/60"
      />
      <Card
        icon={TrendingUpIcon}
        label="Implied Share Price"
        value={fmtPrice(valuation.impliedSharePrice)}
        subText={`vs $${inputs.currentSharePrice.toFixed(2)} current`}
        subColor="text-slate-500"
        onAudit={() => onAudit('sharePrice')}
        accent="bg-emerald-500/60"
      />
      <Card
        icon={isUpside ? TrendingUpIcon : TrendingDown}
        label={isUpside ? "Implied Upside" : "Implied Downside"}
        value={fmtPercent(valuation.upsideDownside)}
        subText={isUpside ? "Accretive vs. market" : "Dilutive vs. market"}
        subColor={isUpside ? "text-emerald-400" : "text-red-400"}
        onAudit={() => onAudit('upside')}
        accent={isUpside ? "bg-emerald-500/60" : "bg-red-500/60"}
      />
    </div>
  );
}