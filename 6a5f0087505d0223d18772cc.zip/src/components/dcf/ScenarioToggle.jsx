import React from 'react';
import { SCENARIO_PRESETS } from '@/lib/dcfEngine';

export default function ScenarioToggle({ scenarioKey, onChange }) {
  return (
    <div className="inline-flex items-center gap-1 bg-slate-900/60 border border-slate-700/50 rounded-lg p-0.5">
      {Object.entries(SCENARIO_PRESETS).map(([key, preset]) => (
        <button
          key={key}
          onClick={() => onChange(key)}
          title={preset.description}
          className={`px-2.5 lg:px-3 py-1.5 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
            scenarioKey === key
              ? 'bg-emerald-500 text-slate-900 shadow-lg shadow-emerald-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
          }`}
        >
          {preset.label}
        </button>
      ))}
    </div>
  );
}