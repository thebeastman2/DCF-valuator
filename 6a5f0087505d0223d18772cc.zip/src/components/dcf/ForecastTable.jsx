import React from 'react';
import { fmtCurrency, fmtPercent } from '@/lib/dcfEngine';

const ROWS = [
  { key: 'revenue', label: 'Revenue', format: fmtCurrency, bold: true },
  { key: 'growth', label: 'Revenue Growth', format: fmtPercent },
  { key: 'grossMargin', label: 'Gross Margin', format: fmtPercent },
  { key: 'grossProfit', label: 'Gross Profit', format: fmtCurrency },
  { key: 'opex', label: 'OpEx', format: fmtCurrency },
  { key: 'ebit', label: 'EBIT', format: fmtCurrency, bold: true },
  { key: 'da', label: 'D&A', format: fmtCurrency },
  { key: 'ebitda', label: 'EBITDA', format: fmtCurrency, bold: true },
  { key: 'capex', label: 'CapEx', format: fmtCurrency },
  { key: 'deltaNWC', label: 'ΔNWC', format: fmtCurrency },
  { key: 'nopat', label: 'NOPAT', format: fmtCurrency },
  { key: 'ufcf', label: 'UFCF', format: fmtCurrency, highlight: true },
];

export default function ForecastTable({ forecast, pvUFCFs }) {
  const pvYears = pvUFCFs || forecast;
  return (
    <div className="bg-[#131825] border border-slate-800/50 rounded-xl overflow-hidden">
      <div className="px-4 py-3 border-b border-slate-800/50">
        <h3 className="text-sm font-semibold text-slate-200">5-Year Financial Forecast & UFCF</h3>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-slate-800/50">
              <th className="text-left px-4 py-2 text-slate-500 font-medium whitespace-nowrap">$M</th>
              {forecast.map(y => (
                <th key={y.year} className="text-right px-3 py-2 text-slate-400 font-medium whitespace-nowrap">Year {y.year}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {ROWS.map(row => (
              <tr key={row.key} className={`border-b border-slate-800/30 ${row.highlight ? 'bg-emerald-500/5' : ''}`}>
                <td className={`px-4 py-2 whitespace-nowrap ${row.bold || row.highlight ? 'text-slate-200 font-medium' : 'text-slate-400'}`}>{row.label}</td>
                {forecast.map(y => (
                  <td key={y.year} className={`text-right px-3 py-2 font-mono whitespace-nowrap ${row.highlight ? 'text-emerald-400 font-semibold' : row.bold ? 'text-slate-200' : 'text-slate-300'}`}>
                    {row.format(y[row.key])}
                  </td>
                ))}
              </tr>
            ))}
            <tr className="bg-slate-800/20">
              <td className="px-4 py-2 text-slate-300 font-medium whitespace-nowrap">PV of UFCF</td>
              {pvYears.map(y => (
                <td key={y.year} className="text-right px-3 py-2 font-mono text-blue-400 font-semibold whitespace-nowrap">
                  {fmtCurrency(y.pvUFCF)}
                </td>
              ))}
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}