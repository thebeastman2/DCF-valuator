import React from 'react';
import { X, FunctionSquare } from 'lucide-react';

export default function AuditModal({ isOpen, onClose, data }) {
  if (!isOpen || !data) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div
        className="bg-[#131825] border border-slate-700/50 rounded-2xl max-w-lg w-full max-h-[80vh] overflow-y-auto shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800/50 sticky top-0 bg-[#131825]">
          <div className="flex items-center gap-2">
            <FunctionSquare className="w-4 h-4 text-emerald-500" />
            <h3 className="text-sm font-semibold text-slate-100">Audit: {data.title}</h3>
          </div>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-200 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="px-5 py-4 space-y-4">
          <div className="bg-slate-900/60 border border-slate-700/30 rounded-lg p-3">
            <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1.5">Formula</div>
            <div className="font-mono text-sm text-emerald-400">{data.formula}</div>
            {data.subFormulas?.map((sf, i) => (
              <div key={i} className="font-mono text-xs text-slate-400 mt-1.5">{sf}</div>
            ))}
          </div>
          <div>
            <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-2">Variable Breakdown</div>
            <div className="space-y-0.5">
              {data.variables.map((v, i) => (
                <div key={i} className="flex items-center justify-between py-1.5 px-2 rounded-md hover:bg-slate-800/30 transition-colors">
                  <div className="flex-1 min-w-0 mr-3">
                    <div className="text-xs text-slate-300 font-medium">{v.label}</div>
                    <div className="text-[10px] text-slate-600">{v.desc}</div>
                  </div>
                  <div className="text-xs font-mono text-slate-200 whitespace-nowrap">{v.value}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}