import React, { useState } from 'react';
import { TrendingUp, LineChart, Calculator, Building, GitMerge, ChevronDown, X } from 'lucide-react';
import NumberField from './NumberField';

function Section({ icon: Icon, title, children, defaultOpen = true }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-slate-800/50">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 px-4 py-3 text-left hover:bg-slate-800/30 transition-colors"
      >
        <Icon className="w-4 h-4 text-emerald-500/80 flex-shrink-0" />
        <span className="text-xs font-semibold text-slate-200 uppercase tracking-wider flex-1">{title}</span>
        <ChevronDown className={`w-4 h-4 text-slate-500 transition-transform flex-shrink-0 ${open ? '' : '-rotate-90'}`} />
      </button>
      {open && <div className="px-4 pb-4 space-y-3">{children}</div>}
    </div>
  );
}

function YearGrid({ label, values, onChange, step }) {
  return (
    <div>
      <label className="text-[11px] font-medium text-slate-400 mb-1.5 block">{label} <span className="text-[10px] text-slate-600">(optional)</span></label>
      <div className="grid grid-cols-5 gap-1.5">
        {values.map((v, i) => (
          <div key={i}>
            <input
              type="number"
              value={v == null ? '' : v * 100}
              step={step}
              onChange={e => { const raw = e.target.value; onChange(i, raw === '' ? null : (parseFloat(raw) || 0) / 100); }}
              placeholder="—"
              className="w-full bg-slate-900/60 border border-slate-700/50 rounded-md py-1.5 text-xs text-slate-100 font-mono text-center focus:outline-none focus:border-emerald-500/60 placeholder:text-slate-700"
            />
            <span className="block text-[9px] text-slate-600 text-center mt-0.5">Y{i + 1}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ToggleGroup({ label, options, value, onChange }) {
  return (
    <div className="space-y-1">
      <label className="text-[11px] font-medium text-slate-400">{label}</label>
      <div className="grid grid-cols-2 gap-1.5">
        {options.map(opt => (
          <button
            key={opt.val}
            onClick={() => onChange(opt.val)}
            className={`py-1.5 text-xs font-medium rounded-md transition-all ${
              value === opt.val
                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                : 'bg-slate-900/60 text-slate-400 border border-slate-700/50 hover:text-slate-200'
            }`}
          >
            {opt.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function SynergySlider({ label, value, min, max, step, onChange, displayFn }) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <label className="text-[11px] font-medium text-slate-400">{label}</label>
        <span className="text-xs font-mono text-emerald-400">{displayFn(value)}</span>
      </div>
      <input
        type="range" min={min} max={max} step={step}
        value={value}
        onChange={e => onChange(parseFloat(e.target.value))}
        className="w-full"
      />
    </div>
  );
}

export default function InputPanel({ inputs, onChange, onClose }) {
  const update = (field, value) => onChange({ ...inputs, [field]: value });
  const updateArray = (field, idx, value) => {
    const arr = [...inputs[field]];
    arr[idx] = value;
    onChange({ ...inputs, [field]: arr });
  };

  return (
    <div className="bg-[#0d1220] border-r border-slate-800/50 flex flex-col h-full w-full">
      <div className="px-4 py-4 border-b border-slate-800/50 flex-shrink-0 flex items-center justify-between">
        <div>
          <h1 className="text-sm font-bold text-slate-100 tracking-tight">DCF Engine Inputs</h1>
          <p className="text-[11px] text-slate-500 mt-0.5">Real-time revaluation on every change</p>
        </div>
        {onClose && (
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200 transition-colors p-1 -mr-1">
            <X className="w-5 h-5" />
          </button>
        )}
      </div>
      <div className="flex-1 overflow-y-auto">
        <Section icon={TrendingUp} title="Baseline Financials">
          <NumberField label="Historical Revenue" value={inputs.historicalRevenue} onChange={v => update('historicalRevenue', v)} prefix="$" suffix="M" step={10} required />
          <NumberField label="Gross Margin" value={inputs.grossMargin} onChange={v => update('grossMargin', v)} isPercent step={0.5} required />
          <NumberField label="Operating Expenses (OpEx)" value={inputs.opex} onChange={v => update('opex', v)} prefix="$" suffix="M" step={10} />
          <NumberField label="Depreciation & Amortization" value={inputs.da} onChange={v => update('da', v)} prefix="$" suffix="M" step={5} />
          <NumberField label="Capital Expenditures" value={inputs.capex} onChange={v => update('capex', v)} prefix="$" suffix="M" step={5} />
          <NumberField label="Change in NWC" value={inputs.deltaNWC} onChange={v => update('deltaNWC', v)} prefix="$" suffix="M" step={5} />
          <NumberField label="Effective Tax Rate" value={inputs.taxRate} onChange={v => update('taxRate', v)} isPercent step={0.5} required />
        </Section>

        <Section icon={LineChart} title="5-Year Forecast Drivers">
          <YearGrid label="Revenue Growth (YoY)" values={inputs.revenueGrowth} onChange={(i, v) => updateArray('revenueGrowth', i, v)} step={0.5} />
          <YearGrid label="Gross Margin Expansion" values={inputs.marginExpansion} onChange={(i, v) => updateArray('marginExpansion', i, v)} step={0.1} />
        </Section>

        <Section icon={Calculator} title="Valuation Drivers">
          <NumberField label="WACC" value={inputs.wacc} onChange={v => update('wacc', v)} isPercent step={0.1} tooltip="Weighted Average Cost of Capital" required />
          <NumberField label="Perpetuity Growth Rate (g)" value={inputs.perpetuityGrowth} onChange={v => update('perpetuityGrowth', v)} isPercent step={0.1} required={inputs.terminalMethod === 'perpetuity'} />
          <NumberField label="Exit EBITDA Multiple" value={inputs.exitMultiple} onChange={v => update('exitMultiple', v)} suffix="x" step={0.5} required={inputs.terminalMethod === 'multiple'} />
          <NumberField label="Current Share Price" value={inputs.currentSharePrice} onChange={v => update('currentSharePrice', v)} prefix="$" step={1} />
          <NumberField label="Fully Diluted Shares (NOSH)" value={inputs.fullyDilutedShares} onChange={v => update('fullyDilutedShares', v)} suffix="M" step={5} required />
          <ToggleGroup
            label="Discounting Convention"
            options={[{ val: 'midyear', label: 'Mid-Year' }, { val: 'yearend', label: 'Year-End' }]}
            value={inputs.discountingConvention}
            onChange={v => update('discountingConvention', v)}
          />
          <ToggleGroup
            label="Terminal Value Method"
            options={[{ val: 'perpetuity', label: 'Gordon Growth' }, { val: 'multiple', label: 'Exit Multiple' }]}
            value={inputs.terminalMethod}
            onChange={v => update('terminalMethod', v)}
          />
        </Section>

        <Section icon={Building} title="Capital Structure">
          <NumberField label="Total Debt" value={inputs.totalDebt} onChange={v => update('totalDebt', v)} prefix="$" suffix="M" step={10} />
          <NumberField label="Cash & Equivalents" value={inputs.cash} onChange={v => update('cash', v)} prefix="$" suffix="M" step={10} />
          <NumberField label="Non-Controlling Interests" value={inputs.nonControllingInterests} onChange={v => update('nonControllingInterests', v)} prefix="$" suffix="M" step={5} />
        </Section>

        <Section icon={GitMerge} title="M&A Synergies" defaultOpen={false}>
          <SynergySlider label="Cost Synergies" value={inputs.costSynergies} min={0} max={100} step={5} onChange={v => update('costSynergies', v)} displayFn={v => `$${v.toFixed(0)}M`} />
          <SynergySlider label="Revenue Synergies" value={inputs.revenueSynergies} min={0} max={200} step={5} onChange={v => update('revenueSynergies', v)} displayFn={v => `$${v.toFixed(0)}M`} />
          <SynergySlider label="Realization %" value={inputs.synergyRealization} min={0} max={1} step={0.05} onChange={v => update('synergyRealization', v)} displayFn={v => `${(v * 100).toFixed(0)}%`} />
          <p className="text-[10px] text-slate-600">Phased: 50% in Year 1, 100% in Year 2+</p>
        </Section>
      </div>
    </div>
  );
}