import React from 'react';
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function CashFlowChart({ forecast }) {
  const data = forecast.map(y => ({
    year: `Y${y.year}`,
    UFCF: parseFloat(y.ufcf.toFixed(1)),
    Revenue: parseFloat(y.revenue.toFixed(1)),
  }));

  return (
    <div className="bg-[#131825] border border-slate-800/50 rounded-xl p-4">
      <h3 className="text-sm font-semibold text-slate-200 mb-4">Cash Flow Trajectory</h3>
      <ResponsiveContainer width="100%" height={280}>
        <ComposedChart data={data} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
          <XAxis dataKey="year" stroke="#475569" fontSize={11} />
          <YAxis yAxisId="left" stroke="#475569" fontSize={11} tickFormatter={v => `$${v}M`} />
          <YAxis yAxisId="right" orientation="right" stroke="#475569" fontSize={11} tickFormatter={v => `$${v}M`} />
          <Tooltip
            contentStyle={{ background: '#0d1220', border: '1px solid #1e293b', borderRadius: '8px', fontSize: '12px' }}
            labelStyle={{ color: '#94a3b8' }}
          />
          <Legend wrapperStyle={{ fontSize: '11px' }} />
          <Bar yAxisId="left" dataKey="UFCF" fill="#10b981" name="UFCF ($M)" radius={[4, 4, 0, 0]} barSize={32} />
          <Line yAxisId="right" dataKey="Revenue" stroke="#3b82f6" strokeWidth={2} name="Revenue ($M)" dot={{ r: 4, fill: '#3b82f6' }} />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
}