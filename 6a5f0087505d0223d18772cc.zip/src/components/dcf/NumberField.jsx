import React from 'react';

export default function NumberField({ label, value, onChange, suffix, prefix, step = 1, isPercent = false, tooltip, required }) {
  const displayValue = isPercent ? (value == null ? null : value * 100) : value;
  const effectiveSuffix = isPercent ? '%' : suffix;
  const effectiveStep = isPercent ? 0.1 : step;

  const handleChange = (e) => {
    const str = e.target.value;
    if (str === '') { onChange(null); return; }
    const raw = parseFloat(str);
    if (isNaN(raw)) { onChange(null); return; }
    onChange(isPercent ? raw / 100 : raw);
  };

  return (
    <div className="space-y-1">
      <label className="text-[11px] font-medium text-slate-400 flex items-center gap-1">
        {label}
        <span className={`text-[10px] ${required ? 'text-emerald-500/70' : 'text-slate-600'}`}>({required ? 'required' : 'optional'})</span>
        {tooltip && <span className="text-slate-600 cursor-help" title={tooltip}>ⓘ</span>}
      </label>
      <div className="relative">
        {prefix && (
          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-500 text-xs pointer-events-none">{prefix}</span>
        )}
        <input
          type="number"
          value={displayValue == null ? '' : displayValue}
          step={effectiveStep}
          onChange={handleChange}
          placeholder="—"
          className="w-full bg-slate-900/60 border border-slate-700/50 rounded-md py-1.5 text-sm text-slate-100 font-mono focus:outline-none focus:border-emerald-500/60 focus:ring-1 focus:ring-emerald-500/20 transition-all placeholder:text-slate-700"
          style={{ paddingLeft: prefix ? '1.5rem' : '0.625rem', paddingRight: effectiveSuffix ? '2rem' : '0.625rem' }}
        />
        {effectiveSuffix && (
          <span className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 text-xs pointer-events-none">{effectiveSuffix}</span>
        )}
      </div>
    </div>
  );
}