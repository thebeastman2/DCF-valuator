import React, { useState } from 'react';

export default function EditableLabel({ value, isPercent, onCommit, title, className }) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState('');

  const displayValue = isPercent ? (value == null ? null : value * 100) : value;

  return (
    <input
      type="text"
      inputMode="decimal"
      value={editing ? draft : (displayValue == null ? '' : String(displayValue))}
      onFocus={() => { setEditing(true); setDraft(displayValue == null ? '' : String(displayValue)); }}
      onChange={e => {
        setDraft(e.target.value);
        const raw = parseFloat(e.target.value);
        if (!isNaN(raw)) onCommit(isPercent ? raw / 100 : raw);
      }}
      onBlur={() => setEditing(false)}
      onKeyDown={e => { if (e.key === 'Enter') e.target.blur(); }}
      title={title}
      className={className}
    />
  );
}