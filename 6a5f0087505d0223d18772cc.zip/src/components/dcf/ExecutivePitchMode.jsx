import React from 'react';
import { X, Download, Presentation } from 'lucide-react';
import MetricCards from './MetricCards';
import CashFlowChart from './CashFlowChart';
import SensitivityHeatmap from './SensitivityHeatmap';
import { fmtCurrency, fmtPercent, fmtMultiple } from '@/lib/dcfEngine';

export default function ExecutivePitchMode({ model, inputs, scenarioLabel, onClose, onExport, onAudit }) {
  return (
    <div className="fixed inset-0 z-40 bg-[#0a0e1a] overflow-y-auto">
      <div className="sticky top-0 z-10 bg-[#0a0e1a]/95 backdrop-blur border-b border-slate-800/50 px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Presentation className="w-5 h-5 text-emerald-500" />
          <div>
            <h2 className="text-sm font-bold text-slate-100">Executive Valuation Summary</h2>
            <p className="text-[11px] text-slate-500">Scenario: {scenarioLabel}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={onExport} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800/60 hover:bg-slate-700/60 rounded-lg transition-colors border border-slate-700/50">
            <Download className="w-3.5 h-3.5" /> Export PDF
          </button>
          <button onClick={onClose} className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800/60 hover:bg-slate-700/60 rounded-lg transition-colors border border-slate-700/50">
            <X className="w-3.5 h-3.5" /> Exit
          </button>
        </div>
      </div>
      <div id="pitch-export-target" className="p-6 space-y-6 max-w-7xl mx-auto">
        <MetricCards model={model} inputs={inputs} onAudit={onAudit} />
        <CashFlowChart forecast={model.forecast} />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {model.sensitivityGrowth ? (
            <SensitivityHeatmap
              sensitivity={model.sensitivityGrowth}
              title="EV Sensitivity: WACC vs. Terminal Growth"
              rowAxisLabel="WACC"
              colAxisLabel="Growth (g)"
              formatCell={v => fmtCurrency(v, 0)}
              formatAxis={v => fmtPercent(v, 1)}
            />
          ) : (
            <div className="bg-[#131825] border border-slate-800/50 rounded-xl p-4 flex items-center justify-center min-h-[200px] text-sm text-slate-500">
              Enter Perpetuity Growth Rate to view this sensitivity
            </div>
          )}
          {model.sensitivityMultiple ? (
            <SensitivityHeatmap
              sensitivity={model.sensitivityMultiple}
              title="EV Sensitivity: WACC vs. Exit Multiple"
              rowAxisLabel="WACC"
              colAxisLabel="Multiple"
              formatCell={v => fmtCurrency(v, 0)}
              formatAxis={v => fmtMultiple(v, 1)}
            />
          ) : (
            <div className="bg-[#131825] border border-slate-800/50 rounded-xl p-4 flex items-center justify-center min-h-[200px] text-sm text-slate-500">
              Enter Exit EBITDA Multiple to view this sensitivity
            </div>
          )}
        </div>
      </div>
    </div>
  );
}