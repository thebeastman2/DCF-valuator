const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useMemo, useEffect } from 'react';
import { Presentation, Download, Menu, TrendingUp, Sparkles, RotateCcw, Calculator, Save, GitCompare } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import {
  BLANK_INPUTS, SAMPLE_INPUTS, SCENARIO_PRESETS, isInputsComplete,
  applyScenario, computeFullModel,
  fmtCurrency, fmtPercent, fmtPrice, fmtMultiple
} from '@/lib/dcfEngine';

import InputPanel from '@/components/dcf/InputPanel';
import ScenarioToggle from '@/components/dcf/ScenarioToggle';
import MetricCards from '@/components/dcf/MetricCards';
import ForecastTable from '@/components/dcf/ForecastTable';
import CashFlowChart from '@/components/dcf/CashFlowChart';
import SensitivityHeatmap from '@/components/dcf/SensitivityHeatmap';
import AuditModal from '@/components/dcf/AuditModal';
import ExecutivePitchMode from '@/components/dcf/ExecutivePitchMode';
import CaseComparison from '@/components/dcf/CaseComparison';
import FuturisticBackground from '@/components/FuturisticBackground';

export default function Valuation() {
  const [inputs, setInputs] = useState(BLANK_INPUTS);
  const [scenarioKey, setScenarioKey] = useState('base');
  const [pitchMode, setPitchMode] = useState(false);
  const [auditType, setAuditType] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [savedCases, setSavedCases] = useState([]);
  const [compareMode, setCompareMode] = useState(false);

  const effectiveInputs = useMemo(() => applyScenario(inputs, scenarioKey), [inputs, scenarioKey]);
  const isComplete = useMemo(() => isInputsComplete(effectiveInputs), [effectiveInputs]);
  const model = useMemo(() => isComplete ? computeFullModel(effectiveInputs) : null, [effectiveInputs, isComplete]);

  useEffect(() => {
    db.entities.SavedCase.list('-created_date', 10)
      .then(setSavedCases)
      .catch(() => {});
  }, []);

  const handleDashScroll = (e) => {
    const bg = document.getElementById('futuristic-bg-inner');
    if (bg) bg.style.transform = `translate3d(0, ${e.currentTarget.scrollTop * 0.15}px, 0)`;
  };

  const loadSample = () => {
    setInputs(SAMPLE_INPUTS);
    setSidebarOpen(true);
  };

  const saveCase = async () => {
    if (!model) return;
    try {
      if (savedCases.length >= 2) {
        const oldest = savedCases[savedCases.length - 1];
        await db.entities.SavedCase.delete(oldest.id);
      }
      await db.entities.SavedCase.create({
        label: `Case ${savedCases.length >= 2 ? 2 : savedCases.length + 1}`,
        inputs: { ...inputs },
        scenario_key: scenarioKey,
      });
      const cases = await db.entities.SavedCase.list('-created_date', 10);
      setSavedCases(cases);
    } catch (e) {}
  };

  const [exporting, setExporting] = useState(false);
  const handleExport = async () => {
    if (exporting) return;
    const element = document.getElementById(pitchMode ? 'pitch-export-target' : 'dashboard-export-target');
    if (!element) return;
    setExporting(true);

    const orig = { overflow: element.style.overflow, height: element.style.height, maxHeight: element.style.maxHeight };
    element.style.overflow = 'visible';
    element.style.height = 'auto';
    element.style.maxHeight = 'none';
    element.scrollTop = 0;
    await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));

    try {
      const canvas = await html2canvas(element, {
        backgroundColor: '#0a0e1a', scale: 2, useCORS: true,
        width: element.scrollWidth, height: element.scrollHeight,
        windowWidth: element.scrollWidth, windowHeight: element.scrollHeight,
      });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('l', 'mm', 'a4');
      const imgWidth = 297;
      const pageHeightMm = 210;
      const imgHeightMm = (canvas.height * imgWidth) / canvas.width;

      let heightLeft = imgHeightMm;
      let position = 0;
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeightMm);
      heightLeft -= pageHeightMm;
      while (heightLeft > 0) {
        position -= pageHeightMm;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeightMm);
        heightLeft -= pageHeightMm;
      }
      pdf.save('dcf-valuation.pdf');
    } finally {
      element.style.overflow = orig.overflow;
      element.style.height = orig.height;
      element.style.maxHeight = orig.maxHeight;
      setExporting(false);
    }
  };

  const getAuditData = (type) => {
    if (!type || !model) return null;
    const { forecast, valuation } = model;
    const y1 = forecast[0];

    switch (type) {
      case 'ufcf':
        return {
          title: 'Unlevered Free Cash Flow',
          formula: 'UFCF = NOPAT + D&A − CapEx − ΔNWC',
          subFormulas: ['EBIT = Revenue × Gross Margin − OpEx', 'NOPAT = EBIT × (1 − τ)'],
          variables: [
            { label: 'Revenue (Y1)', value: fmtCurrency(y1.revenue), desc: 'Prior revenue × (1 + growth) + synergies' },
            { label: 'Gross Margin (Y1)', value: fmtPercent(y1.grossMargin), desc: 'Base margin + expansion' },
            { label: 'EBIT (Y1)', value: fmtCurrency(y1.ebit), desc: 'Gross Profit − OpEx' },
            { label: 'Tax Rate (τ)', value: fmtPercent(inputs.taxRate), desc: 'Effective corporate tax rate' },
            { label: 'NOPAT (Y1)', value: fmtCurrency(y1.nopat), desc: 'EBIT × (1 − τ)' },
            { label: 'D&A (Y1)', value: fmtCurrency(y1.da), desc: 'Depreciation & Amortization' },
            { label: 'CapEx (Y1)', value: fmtCurrency(y1.capex), desc: 'Capital Expenditures' },
            { label: 'ΔNWC (Y1)', value: fmtCurrency(y1.deltaNWC), desc: 'Change in Net Working Capital' },
            { label: 'UFCF (Y1)', value: fmtCurrency(y1.ufcf), desc: 'NOPAT + D&A − CapEx − ΔNWC' },
          ],
        };
      case 'ev':
        return {
          title: 'Enterprise Value',
          formula: 'EV = Σ PV(UFCF) + PV(Terminal Value)',
          subFormulas: [
            `PV(UFCF_t) = UFCF_t / (1 + WACC)^(t − ${valuation.midpoint})`,
            inputs.terminalMethod === 'perpetuity'
              ? `TV = UFCF_n × (1 + g) / (WACC − g)`
              : `TV = EBITDA_n × Exit Multiple`,
            `PV(TV) = TV / (1 + WACC)^n`,
          ],
          variables: [
            { label: 'Σ PV(UFCF)', value: fmtCurrency(valuation.sumPvUFCF), desc: 'Sum of discounted UFCFs (5 years)' },
            { label: 'Terminal Value', value: fmtCurrency(valuation.terminalValue), desc: inputs.terminalMethod === 'perpetuity' ? 'Gordon Growth Method' : 'Exit Multiple Method' },
            { label: 'PV(Terminal Value)', value: fmtCurrency(valuation.pvTerminal), desc: 'TV discounted at Year n' },
            { label: 'WACC', value: fmtPercent(inputs.wacc), desc: 'Discount rate' },
            { label: 'Discount Convention', value: inputs.discountingConvention === 'midyear' ? 'Mid-Year' : 'Year-End', desc: 'Timing convention' },
            { label: 'Enterprise Value', value: fmtCurrency(valuation.enterpriseValue), desc: 'PV(UFCF) + PV(TV)' },
          ],
        };
      case 'equity':
        return {
          title: 'Implied Equity Value',
          formula: 'Equity = EV − Total Debt + Cash − NCI',
          variables: [
            { label: 'Enterprise Value', value: fmtCurrency(valuation.enterpriseValue), desc: 'PV(UFCF) + PV(TV)' },
            { label: 'Total Debt', value: fmtCurrency(inputs.totalDebt), desc: 'Subtracted from EV' },
            { label: 'Cash & Equivalents', value: fmtCurrency(inputs.cash), desc: 'Added to EV' },
            { label: 'Non-Controlling Interests', value: fmtCurrency(inputs.nonControllingInterests), desc: 'Subtracted from EV' },
            { label: 'Implied Equity Value', value: fmtCurrency(valuation.equityValue), desc: 'EV − Debt + Cash − NCI' },
          ],
        };
      case 'sharePrice':
        return {
          title: 'Implied Share Price',
          formula: 'Share Price = Equity Value / Fully Diluted Shares (NOSH)',
          variables: [
            { label: 'Implied Equity Value', value: fmtCurrency(valuation.equityValue), desc: 'EV − Debt + Cash − NCI' },
            { label: 'Fully Diluted Shares', value: `${inputs.fullyDilutedShares}M`, desc: 'NOSH' },
            { label: 'Implied Share Price', value: fmtPrice(valuation.impliedSharePrice), desc: 'Equity / NOSH' },
            { label: 'Current Trading Price', value: fmtPrice(inputs.currentSharePrice), desc: 'Market reference' },
          ],
        };
      case 'upside':
        return {
          title: 'Implied Upside / Downside',
          formula: 'Upside % = (Implied Price − Current Price) / Current Price',
          variables: [
            { label: 'Implied Share Price', value: fmtPrice(valuation.impliedSharePrice), desc: 'From DCF model' },
            { label: 'Current Share Price', value: fmtPrice(inputs.currentSharePrice), desc: 'Market reference' },
            { label: 'Upside / Downside', value: fmtPercent(valuation.upsideDownside), desc: 'Premium / Discount to market' },
          ],
        };
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col lg:flex-row h-screen bg-[#0a0e1a] text-slate-100 overflow-hidden">
      <FuturisticBackground />
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-30 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'fixed inset-y-0 left-0 z-40 lg:relative lg:z-auto' : 'hidden'} w-80 lg:w-72 xl:w-80 flex-shrink-0 lg:h-full`}>
        <InputPanel inputs={inputs} onChange={setInputs} onClose={() => setSidebarOpen(false)} />
      </div>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden relative z-10">
        {/* Header */}
        <header className="flex items-center justify-between px-4 lg:px-6 py-3 border-b border-slate-800/50 bg-[#0d1220]/50 backdrop-blur flex-shrink-0">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-slate-400 hover:text-slate-200">
              <Menu className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                <TrendingUp className="w-4 h-4 text-emerald-500" />
              </div>
              <div>
                <h1 className="text-sm font-bold text-slate-100 leading-none">DCF Valuation Engine</h1>
                <p className="text-[10px] text-slate-500 mt-0.5">M&A Sensitivity Analysis</p>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 lg:gap-3">
            <div className="hidden md:block">
              <ScenarioToggle scenarioKey={scenarioKey} onChange={setScenarioKey} />
            </div>
            <button
              onClick={loadSample}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 rounded-lg transition-colors border border-emerald-500/20"
            >
              <Sparkles className="w-3.5 h-3.5" /> <span className="hidden sm:inline">Sample Deal</span>
            </button>
            <button
              onClick={() => setInputs(BLANK_INPUTS)}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-400 bg-slate-800/60 hover:bg-slate-700/60 rounded-lg transition-colors border border-slate-700/50"
            >
              <RotateCcw className="w-3.5 h-3.5" /> <span className="hidden sm:inline">Reset</span>
            </button>
            <button
              onClick={saveCase}
              disabled={!model}
              className={`hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800/60 hover:bg-slate-700/60 rounded-lg transition-colors border border-slate-700/50 ${!model ? 'opacity-40 cursor-not-allowed' : ''}`}
            >
              <Save className="w-3.5 h-3.5" /> <span className="hidden lg:inline">Save Case</span>
            </button>
            <button
              onClick={() => setCompareMode(true)}
              disabled={!model}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800/60 hover:bg-slate-700/60 rounded-lg transition-colors border border-slate-700/50 ${!model ? 'opacity-40 cursor-not-allowed' : ''}`}
            >
              <GitCompare className="w-3.5 h-3.5" /> <span className="hidden sm:inline">Compare</span>
            </button>
            <button
              onClick={handleExport}
              disabled={!model || exporting}
              className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-800/60 hover:bg-slate-700/60 rounded-lg transition-colors border border-slate-700/50 ${(!model || exporting) ? 'opacity-40 cursor-not-allowed' : ''}`}
            >
              <Download className={`w-3.5 h-3.5 ${exporting ? 'animate-spin' : ''}`} /> {exporting ? 'Exporting...' : 'Export'}
            </button>
            <button
              onClick={() => model && setPitchMode(true)}
              disabled={!model}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-900 bg-emerald-500 hover:bg-emerald-400 rounded-lg transition-colors ${!model ? 'opacity-40 cursor-not-allowed' : ''}`}
            >
              <Presentation className="w-3.5 h-3.5" /> <span className="hidden sm:inline">Pitch Mode</span>
            </button>
          </div>
        </header>

        {/* Mobile scenario toggle */}
        <div className="md:hidden px-4 py-2 border-b border-slate-800/50 bg-[#0d1220]/30">
          <ScenarioToggle scenarioKey={scenarioKey} onChange={setScenarioKey} />
        </div>

        {/* Dashboard or Empty State */}
        {model ? (
          <div id="dashboard-export-target" className="flex-1 overflow-y-auto p-4 lg:p-6 space-y-6 dash-3d" onScroll={handleDashScroll}>
            <MetricCards model={model} inputs={effectiveInputs} onAudit={setAuditType} />

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              <ForecastTable forecast={model.forecast} pvUFCFs={model.valuation.pvUFCFs} />
              <CashFlowChart forecast={model.forecast} />
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              {model.sensitivityGrowth ? (
                <SensitivityHeatmap
                  sensitivity={model.sensitivityGrowth}
                  title="EV Sensitivity: WACC vs. Terminal Growth"
                  rowAxisLabel="WACC"
                  colAxisLabel="Growth (g)"
                  formatCell={v => fmtCurrency(v, 0)}
                  formatAxis={v => fmtPercent(v, 1)}
                  onEditRow={v => setInputs({ ...inputs, wacc: v })}
                  onEditCol={v => setInputs({ ...inputs, perpetuityGrowth: v })}
                  rowIsPercent
                  colIsPercent
                />
              ) : (
                <div className="bg-[#131825] border border-slate-800/50 rounded-xl p-4 flex items-center justify-center min-h-[200px] text-sm text-slate-500">
                  Enter Perpetuity Growth Rate to view this sensitivity
                </div>
              )}
              {model.sensitivityMultiple ? (
                <SensitivityHeatmap
                  sensitivity={model.sensitivityMultiple}
                  title="EV Sensitivity: WACC vs. Exit Multiple"
                  rowAxisLabel="WACC"
                  colAxisLabel="Multiple"
                  formatCell={v => fmtCurrency(v, 0)}
                  formatAxis={v => fmtMultiple(v, 1)}
                  onEditRow={v => setInputs({ ...inputs, wacc: v })}
                  onEditCol={v => setInputs({ ...inputs, exitMultiple: v })}
                  rowIsPercent
                />
              ) : (
                <div className="bg-[#131825] border border-slate-800/50 rounded-xl p-4 flex items-center justify-center min-h-[200px] text-sm text-slate-500">
                  Enter Exit EBITDA Multiple to view this sensitivity
                </div>
              )}
            </div>

            {/* UFCF Audit summary */}
            <div className="bg-[#131825] border border-slate-800/50 rounded-xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-slate-200">UFCF Computation Audit</h3>
                <button onClick={() => setAuditType('ufcf')} className="text-xs text-emerald-400 hover:text-emerald-300 transition-colors">
                  View Formula →
                </button>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                {model.forecast.map(y => (
                  <div key={y.year} className="bg-slate-900/40 rounded-lg p-3 border border-slate-800/30">
                    <div className="text-[10px] text-slate-500 uppercase tracking-wider mb-1">Year {y.year}</div>
                    <div className="text-sm font-mono font-bold text-emerald-400">{fmtCurrency(y.ufcf)}</div>
                    <div className="text-[10px] text-slate-600 mt-1">NOPAT: {fmtCurrency(y.nopat)}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div className="flex-1 flex items-center justify-center p-8">
            <div className="text-center max-w-md">
              <button
                onClick={() => setSidebarOpen(true)}
                className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mx-auto mb-4 hover:bg-emerald-500/20 transition-colors group"
              >
                <Calculator className="w-8 h-8 text-emerald-500 group-hover:scale-110 transition-transform" />
              </button>
              <h2 className="text-lg font-semibold text-slate-200 mb-2">Enter Your Deal Assumptions</h2>
              <p className="text-sm text-slate-500 mb-6">
                Click the calculator above to open the input panel, then fill in the required fields to run the DCF valuation. All calculations update in real time once inputs are provided.
              </p>
              <button
                onClick={loadSample}
                className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 rounded-lg transition-colors border border-emerald-500/20"
              >
                <Sparkles className="w-4 h-4" /> Load Sample Deal
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Pitch Mode overlay */}
      {pitchMode && model && (
        <ExecutivePitchMode
          model={model}
          inputs={effectiveInputs}
          scenarioLabel={SCENARIO_PRESETS[scenarioKey].label}
          onClose={() => setPitchMode(false)}
          onExport={handleExport}
          onAudit={setAuditType}
        />
      )}

      {/* Case Comparison overlay */}
      {compareMode && model && (
        <CaseComparison
          currentInputs={effectiveInputs}
          currentModel={model}
          savedCases={savedCases}
          onClose={() => setCompareMode(false)}
          onDeleteCase={async (id) => {
            try {
              await db.entities.SavedCase.delete(id);
              const cases = await db.entities.SavedCase.list('-created_date', 10);
              setSavedCases(cases);
            } catch (e) {}
          }}
        />
      )}

      {/* Audit Modal */}
      <AuditModal isOpen={!!auditType} onClose={() => setAuditType(null)} data={getAuditData(auditType)} />
    </div>
  );
}